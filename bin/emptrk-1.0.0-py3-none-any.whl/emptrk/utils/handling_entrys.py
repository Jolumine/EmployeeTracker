def modify_entry():
    pass 

def delete_entry():
    pass

